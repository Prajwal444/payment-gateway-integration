<!DOCTYPE html>
<html>

  <head>
    <?php include('head.php'); ?>
    <title>Relief Fund </title>
  </head>

  <body>

    <header>
    <?php include('navbar.php'); ?>
      <main>

        <section>
          <h3>
            Covid-19 Fund Raiser.
          </h3>
          <p>“Giving is not just about making a donation. It is about making a difference.”
          </p>
                <p class=" animated infinite heartBeat">"Poverty Shouldn't Be Their Destiny"</p>
       <form class="razorpay-embed-btn">
           <script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_IBFChKakcHmhR1" async> </script> </form>

      </main>

    </header>
    <?php include('footer.php'); ?>

   
    </div>
    </div>
    </div>

    </div>


  </body>

</html>



