 <!-- footer -->
    <footer>
        
      <div class="row text-center ">
        <div class="col-md-6">
          <h4>
            <small>© Copyright 2021, Relief Fund  (The Sparks Foundation)</small>
          </h4>
          <h3>Made By Prajwal Sahare </h3>

        </div>
        <div class="col-md-6 text-center">
          <ul class="social-icons">
            Connect Me ✉️ :

            <i class="fab fa-github"><a target="_blank"  class="icons"  href="https://github.com/Prajwal444"><img class="bg-white" src="g.png" alt="none"></a></i>
            <a target="_blank" class="icons" href="https://www.linkedin.com/in/prajwal-sahare-9378771b4"><img class="bg-white" src="linkedin.png" alt="linkedin" height="32" width="32"></a>
          </ul>
        </div>
      </div>
    </footer>
