 <nav>

        <div class="menu mt-3">

<button type="button" class="btn btn-warning mt-6">          <a href="index.php">Home</a></button>
<button type="button" class="btn btn-warning mt-6">          <a href="about.php">About</a></button>
<button type="button" class="btn btn-warning mt-6">          <a href="contact.php">Contact Us</a></button>


        </div>
        <div class="logo">
          <h1>
            THE SPARK FOUNDATION  </h1>
        </div>
      </nav>